<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\{Artisan, Schema, DB};
use Tests\TestCase;
use App\Models\{Category, Question, QuestionOption, QuestionAnswer, Test};

class SavedTestStepNextQuestionCheckTest extends TestCase
{
    /** @test */
    public function next_question_can_be_checked_after_correct_answer(): void
    {
        $migrations = [
            '2025_07_20_143201_create_categories_table.php',
            '2025_07_20_143210_create_quastion_table.php',
            '2025_07_20_143230_create_quastion_options_table.php',
            '2025_07_20_143243_create_quastion_answers_table.php',
            '2025_07_20_164021_add_verb_hint_to_question_answers.php',
            '2025_07_20_180521_add_flag_to_question_table.php',
            '2025_07_20_193626_add_source_to_qustion_table.php',
            '2025_07_27_000001_add_unique_index_to_question_answers.php',
            '2025_07_28_000002_create_verb_hints_table.php',
            '2025_07_29_000001_create_question_option_question_table.php',
            '2025_07_30_000001_create_tags_table.php',
            '2025_07_30_000003_create_question_tag_table.php',
            '2025_07_31_000002_add_uuid_to_questions_table.php',
            '2025_07_20_184450_create_tests_table.php',
            '2025_08_04_000002_add_description_to_tests_table.php',
        ];
        foreach ($migrations as $file) {
            Artisan::call('migrate', ['--path' => 'database/migrations/' . $file]);
        }

        DB::statement('DROP TABLE question_options');
        DB::statement('CREATE TABLE question_options (id INTEGER PRIMARY KEY AUTOINCREMENT, option VARCHAR UNIQUE, created_at DATETIME, updated_at DATETIME)');
        Schema::table('question_option_question', function ($table) {
            $table->tinyInteger('flag')->nullable()->after('option_id');
        });

        $category = Category::create(['name' => 'cat']);

        $q1 = Question::create([
            'uuid' => 'q1',
            'question' => 'Q1 {a1}',
            'difficulty' => 1,
            'category_id' => $category->id,
        ]);
        $opt1 = QuestionOption::create(['option' => 'yes']);
        $q1->options()->attach($opt1->id);
        $ans1 = new QuestionAnswer(['marker' => 'a1']);
        $ans1->answer = 'yes';
        $ans1->question_id = $q1->id;
        $ans1->save();

        $q2 = Question::create([
            'uuid' => 'q2',
            'question' => 'Q2 {a1}',
            'difficulty' => 1,
            'category_id' => $category->id,
        ]);
        $opt2 = QuestionOption::create(['option' => 'ok']);
        $q2->options()->attach($opt2->id);
        $ans2 = new QuestionAnswer(['marker' => 'a1']);
        $ans2->answer = 'ok';
        $ans2->question_id = $q2->id;
        $ans2->save();

        $testModel = Test::create([
            'name' => 'sample',
            'slug' => 'sample',
            'filters' => [],
            'questions' => [$q1->id, $q2->id],
        ]);

        $this->post('/admin/test/'.$testModel->slug.'/step/check', [
            'question_id' => $q1->id,
            'answers' => ['a1' => 'yes'],
        ]);

        $this->get('/admin/test/'.$testModel->slug.'/step')
            ->assertSee('Q1', false)
            ->assertSee('Correct!', false);

        $this->get('/admin/test/'.$testModel->slug.'/step?nav=next')
            ->assertSee('Q2', false)
            ->assertSee('Check');

        $this->post('/admin/test/'.$testModel->slug.'/step/check', [
            'question_id' => $q2->id,
            'answers' => ['a1' => 'no'],
        ]);

        $this->get('/admin/test/'.$testModel->slug.'/step')
            ->assertSee('Q2', false)
            ->assertSee('Wrong', false);
    }
}
