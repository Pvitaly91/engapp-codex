<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionVariant extends Model
{
    protected $fillable = ['question_id', 'text'];

    public function question()
    {
        return $this->belongsTo(Question::class);
    }
}
