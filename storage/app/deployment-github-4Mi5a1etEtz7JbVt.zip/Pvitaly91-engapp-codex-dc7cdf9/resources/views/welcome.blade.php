@extends('layouts.app')

@section('title', 'Welcome')

@section('content')
<div class="text-center p-8">
    <h1 class="text-3xl font-bold mb-4">Laravel</h1>
    <p class="text-gray-600">Welcome to Laravel!</p>
</div>
@endsection

