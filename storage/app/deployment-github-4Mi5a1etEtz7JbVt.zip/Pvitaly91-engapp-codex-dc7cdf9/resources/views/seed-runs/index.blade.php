@extends('layouts.app')

@section('title', 'Seed Runs')

@section('content')
    <div class="max-w-6xl mx-auto space-y-6">
        @php $recentSeedRunOrdinals = collect($recentSeedRunOrdinals ?? []); @endphp
        <div class="bg-white shadow rounded-lg p-6">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h1 class="text-2xl font-semibold text-gray-800">Seed Runs</h1>
                    <p class="text-sm text-gray-500">Керуйте виконаними та невиконаними сидарами.</p>
                </div>
                @if($tableExists)
                    <form method="POST" action="{{ route('seed-runs.run-missing') }}" data-preloader>
                        @csrf
                        <button type="submit" class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md shadow hover:bg-blue-500 transition disabled:opacity-50" @if($pendingSeeders->isEmpty()) disabled @endif>
                            <i class="fa-solid fa-play"></i>
                            Виконати всі невиконані
                        </button>
                    </form>
                @endif
            </div>

            @if(session('status'))
                <div class="mb-4 rounded-md bg-green-50 border border-green-200 px-4 py-3 text-green-700">
                    {{ session('status') }}
                </div>
            @endif

            @if($errors->any())
                <div class="mb-4 rounded-md bg-red-50 border border-red-200 px-4 py-3 text-red-700">
                    <ul class="list-disc list-inside space-y-1">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div id="seed-run-ajax-feedback" class="hidden mb-4 rounded-md border px-4 py-3 text-sm"></div>

            @unless($tableExists)
                <div class="rounded-md bg-yellow-50 border border-yellow-200 px-4 py-3 text-yellow-800">
                    Таблиця <code class="font-mono">seed_runs</code> ще не створена. Запустіть міграції, щоб продовжити.
                </div>
            @endunless
        </div>

        @if($tableExists)
            <div >
                <div class="bg-white shadow rounded-lg p-6 my-4">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">Невиконані сидери</h2>
                    @if($pendingSeeders->isEmpty())
                        <p class="text-sm text-gray-500">Усі сидери вже виконані.</p>
                    @else
                        <ul class="space-y-3">
                            @foreach($pendingSeeders as $pendingSeeder)
                                <li class="flex items-center justify-between gap-4">
                                    <span class="text-sm font-mono text-gray-700 break-all">{{ $pendingSeeder->display_class_name }}</span>
                                    <form method="POST" action="{{ route('seed-runs.run') }}" data-preloader>
                                        @csrf
                                        <input type="hidden" name="class_name" value="{{ $pendingSeeder->class_name }}">
                                        <button type="submit" class="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-600 text-white text-xs font-medium rounded-md hover:bg-emerald-500 transition">
                                            <i class="fa-solid fa-play"></i>
                                            Виконати
                                        </button>
                                    </form>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </div>

                <div class="bg-white shadow rounded-lg p-6 overflow-hidden">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">Виконані сидери</h2>
                    @if($executedSeederHierarchy->isEmpty())
                        <p class="text-sm text-gray-500">Поки що немає виконаних сидерів.</p>
                    @else
                        <div class="space-y-4">
                            @foreach($executedSeederHierarchy as $node)
                                @include('seed-runs.partials.executed-node', [
                                    'node' => $node,
                                    'depth' => 0,
                                    'recentSeedRunOrdinals' => $recentSeedRunOrdinals,
                                ])
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        @endif
    </div>

    <div id="seed-run-preloader" class="hidden fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-lg px-6 py-4 flex items-center gap-3 text-sm text-gray-700">
            <span class="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></span>
            <span>Виконується операція…</span>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const preloader = document.getElementById('seed-run-preloader');
            const feedback = document.getElementById('seed-run-ajax-feedback');
            const csrfTokenMeta = document.querySelector('meta[name="csrf-token"]');
            const csrfToken = csrfTokenMeta ? csrfTokenMeta.getAttribute('content') : '';
            const successClasses = ['bg-emerald-50', 'border-emerald-200', 'text-emerald-700'];
            const errorClasses = ['bg-red-50', 'border-red-200', 'text-red-700'];
            let feedbackTimeout;

            document.querySelectorAll('form[data-preloader]').forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    const confirmMessage = form.dataset.confirm;

                    if (confirmMessage && !window.confirm(confirmMessage)) {
                        event.preventDefault();

                        return;
                    }

                    if (preloader) {
                        preloader.classList.remove('hidden');
                    }
                });
            });

            const showFeedback = function (message, type = 'success') {
                if (!feedback) {
                    return;
                }

                feedback.textContent = message;
                feedback.classList.remove('hidden');
                feedback.classList.remove(...successClasses, ...errorClasses);

                const classes = type === 'error' ? errorClasses : successClasses;
                classes.forEach(function (className) {
                    feedback.classList.add(className);
                });

                window.clearTimeout(feedbackTimeout);
                feedbackTimeout = window.setTimeout(function () {
                    feedback.classList.add('hidden');
                }, 5000);
            };

            const updateToggleLabels = function (button, expanded) {
                const collapsedLabel = button.querySelector('[data-toggle-label-collapsed]');
                const expandedLabel = button.querySelector('[data-toggle-label-expanded]');

                if (collapsedLabel) {
                    collapsedLabel.classList.toggle('hidden', expanded);
                }

                if (expandedLabel) {
                    expandedLabel.classList.toggle('hidden', !expanded);
                }
            };

            const decrementNumericContent = function (elements) {
                elements.forEach(function (element) {
                    const current = parseInt(element.textContent.trim(), 10);

                    if (Number.isNaN(current)) {
                        return;
                    }

                    const nextValue = Math.max(0, current - 1);
                    element.textContent = nextValue;
                });
            };

            const hasPositiveCount = function (elements) {
                return Array.from(elements).some(function (element) {
                    const value = parseInt(element.textContent.trim(), 10);

                    return Number.isFinite(value) && value > 0;
                });
            };

            const cleanupEmptyGroups = function (seedRunId, categoryKey, sourceKey) {
                const sourceWrappers = document.querySelectorAll('[data-source-wrapper][data-seed-run-id="' + seedRunId + '"][data-category-key="' + categoryKey + '"][data-source-key="' + sourceKey + '"]');
                sourceWrappers.forEach(function (wrapper) {
                    const questionList = wrapper.querySelector('[data-source-questions]');

                    if (!questionList || questionList.querySelector('[data-question-container]')) {
                        return;
                    }

                    wrapper.remove();
                });

                const categoryWrappers = document.querySelectorAll('[data-category-wrapper][data-seed-run-id="' + seedRunId + '"][data-category-key="' + categoryKey + '"]');
                categoryWrappers.forEach(function (wrapper) {
                    if (wrapper.querySelector('[data-question-container]')) {
                        return;
                    }

                    if (wrapper.querySelector('[data-source-wrapper]')) {
                        return;
                    }

                    wrapper.remove();
                });

                const seederContent = document.querySelector('[data-seeder-content][data-seed-run-id="' + seedRunId + '"]');
                const seederSection = document.querySelector('[data-seeder-section][data-seed-run-id="' + seedRunId + '"]');
                const toggleButton = document.querySelector('[data-seeder-toggle][data-seed-run-id="' + seedRunId + '"]');
                const noQuestionsMessage = document.querySelector('[data-no-questions-message][data-seed-run-id="' + seedRunId + '"]');
                const seederCounts = document.querySelectorAll('[data-seed-run-question-count][data-seed-run-id="' + seedRunId + '"]');
                const remainingQuestions = hasPositiveCount(seederCounts);

                if (!remainingQuestions) {
                    if (seederContent) {
                        seederContent.innerHTML = '';
                        seederContent.classList.add('hidden');
                    }

                    if (seederSection) {
                        seederSection.classList.add('hidden');
                    }

                    if (toggleButton) {
                        toggleButton.dataset.loaded = 'false';
                        toggleButton.classList.add('hidden');
                        toggleButton.setAttribute('aria-expanded', 'false');
                        updateToggleLabels(toggleButton, false);

                        const icon = toggleButton.querySelector('[data-seeder-toggle-icon]');

                        if (icon) {
                            icon.classList.remove('rotate-180');
                        }
                    }

                    if (noQuestionsMessage) {
                        noQuestionsMessage.classList.remove('hidden');
                    }
                }
            };

            const handleFolderToggle = async function (button) {
                const folderNode = button.closest('[data-folder-node]');

                if (!folderNode) {
                    return;
                }

                const children = folderNode.querySelector('[data-folder-children]');

                if (!children) {
                    return;
                }

                const isExpanded = button.getAttribute('aria-expanded') === 'true';
                const icon = button.querySelector('[data-folder-icon]');

                if (isExpanded) {
                    button.setAttribute('aria-expanded', 'false');

                    if (icon) {
                        icon.classList.add('-rotate-90');
                    }

                    children.classList.add('hidden');

                    return;
                }

                button.setAttribute('aria-expanded', 'true');

                if (icon) {
                    icon.classList.remove('-rotate-90');
                }

                children.classList.remove('hidden');

                if (folderNode.dataset.loaded === 'true') {
                    return;
                }

                const baseUrl = button.dataset.loadUrl;

                if (!baseUrl) {
                    return;
                }

                folderNode.dataset.loaded = 'loading';
                const depth = children.dataset.depth || '0';
                const path = button.dataset.folderPath || '';
                const params = new URLSearchParams({
                    path: path,
                    depth: depth,
                });

                children.innerHTML = '<p class="text-xs text-gray-500">Завантаження…</p>';

                try {
                    const response = await fetch(baseUrl + '?' + params.toString(), {
                        headers: {
                            'Accept': 'application/json',
                        },
                    });

                    const payload = await response.json().catch(function () {
                        return null;
                    });

                    if (!response.ok) {
                        const message = payload && typeof payload.message === 'string'
                            ? payload.message
                            : 'Не вдалося завантажити вміст папки.';
                        throw new Error(message);
                    }

                    children.innerHTML = payload && typeof payload.html === 'string'
                        ? payload.html
                        : '';
                    folderNode.dataset.loaded = 'true';
                } catch (error) {
                    const message = error && typeof error.message === 'string' && error.message
                        ? error.message
                        : 'Не вдалося завантажити вміст папки.';

                    children.innerHTML = '<p class="text-xs text-red-600">' + message + '</p>';
                    folderNode.dataset.loaded = 'error';
                    showFeedback(message, 'error');
                }
            };

            const handleSeederToggle = async function (button) {
                const seedRunId = button.dataset.seedRunId;
                const seederNode = button.closest('[data-seeder-node]');

                if (!seedRunId || !seederNode) {
                    return;
                }

                const content = seederNode.querySelector('[data-seeder-content][data-seed-run-id="' + seedRunId + '"]');

                if (!content) {
                    return;
                }

                const isExpanded = button.getAttribute('aria-expanded') === 'true';
                const icon = button.querySelector('[data-seeder-toggle-icon]');

                if (isExpanded) {
                    button.setAttribute('aria-expanded', 'false');
                    updateToggleLabels(button, false);

                    if (icon) {
                        icon.classList.remove('rotate-180');
                    }

                    content.classList.add('hidden');

                    return;
                }

                button.setAttribute('aria-expanded', 'true');
                updateToggleLabels(button, true);

                if (icon) {
                    icon.classList.add('rotate-180');
                }

                content.classList.remove('hidden');

                if (button.dataset.loaded === 'true') {
                    return;
                }

                const url = button.dataset.loadUrl;

                if (!url) {
                    return;
                }

                button.dataset.loaded = 'loading';
                content.innerHTML = '<p class="text-xs text-gray-500">Завантаження…</p>';

                try {
                    const response = await fetch(url, {
                        headers: {
                            'Accept': 'application/json',
                        },
                    });

                    const payload = await response.json().catch(function () {
                        return null;
                    });

                    if (!response.ok) {
                        const message = payload && typeof payload.message === 'string'
                            ? payload.message
                            : 'Не вдалося завантажити питання.';
                        throw new Error(message);
                    }

                    content.innerHTML = payload && typeof payload.html === 'string'
                        ? payload.html
                        : '';
                    button.dataset.loaded = 'true';

                    if (!content.innerHTML.trim()) {
                        content.innerHTML = '<p class="text-xs text-gray-500">Питання для цього сидера не знайдені.</p>';
                    }
                } catch (error) {
                    const message = error && typeof error.message === 'string' && error.message
                        ? error.message
                        : 'Не вдалося завантажити питання.';

                    content.innerHTML = '<p class="text-xs text-red-600">' + message + '</p>';
                    button.dataset.loaded = 'error';
                    showFeedback(message, 'error');
                }
            };

            const handleSourceToggle = async function (button) {
                const seedRunId = button.dataset.seedRunId;
                const categoryKey = button.dataset.categoryKey;
                const sourceKey = button.dataset.sourceKey;
                const sourceWrapper = button.closest('[data-source-wrapper]');

                if (!seedRunId || !categoryKey || !sourceKey || !sourceWrapper) {
                    return;
                }

                const questionsContainer = sourceWrapper.querySelector('[data-source-questions][data-seed-run-id="' + seedRunId + '"][data-category-key="' + categoryKey + '"][data-source-key="' + sourceKey + '"]');

                if (!questionsContainer) {
                    return;
                }

                const isExpanded = button.getAttribute('aria-expanded') === 'true';
                const icon = button.querySelector('[data-source-toggle-icon]');

                if (isExpanded) {
                    button.setAttribute('aria-expanded', 'false');
                    updateToggleLabels(button, false);

                    if (icon) {
                        icon.classList.remove('rotate-180');
                    }

                    questionsContainer.classList.add('hidden');

                    return;
                }

                button.setAttribute('aria-expanded', 'true');
                updateToggleLabels(button, true);

                if (icon) {
                    icon.classList.add('rotate-180');
                }

                questionsContainer.classList.remove('hidden');

                if (button.dataset.loaded === 'true') {
                    return;
                }

                const url = button.dataset.loadUrl;

                if (!url) {
                    return;
                }

                button.dataset.loaded = 'loading';
                questionsContainer.innerHTML = '<p class="text-xs text-gray-500">Завантаження…</p>';

                try {
                    const response = await fetch(url, {
                        headers: {
                            'Accept': 'application/json',
                        },
                    });

                    const payload = await response.json().catch(function () {
                        return null;
                    });

                    if (!response.ok) {
                        const message = payload && typeof payload.message === 'string'
                            ? payload.message
                            : 'Не вдалося завантажити питання.';
                        throw new Error(message);
                    }

                    questionsContainer.innerHTML = payload && typeof payload.html === 'string'
                        ? payload.html
                        : '';
                    button.dataset.loaded = 'true';

                    if (!questionsContainer.innerHTML.trim()) {
                        questionsContainer.innerHTML = '<p class="text-xs text-gray-500">Питань не знайдено.</p>';
                    }
                } catch (error) {
                    const message = error && typeof error.message === 'string' && error.message
                        ? error.message
                        : 'Не вдалося завантажити питання.';

                    questionsContainer.innerHTML = '<p class="text-xs text-red-600">' + message + '</p>';
                    button.dataset.loaded = 'error';
                    showFeedback(message, 'error');
                }
            };

            const handleQuestionToggle = async function (button) {
                const container = button.closest('[data-question-container]');

                if (!container) {
                    return;
                }

                const answersContainer = container.querySelector('[data-question-answers]');

                if (!answersContainer) {
                    return;
                }

                const isExpanded = button.getAttribute('aria-expanded') === 'true';
                const icon = button.querySelector('[data-question-toggle-icon]');

                if (isExpanded) {
                    button.setAttribute('aria-expanded', 'false');
                    updateToggleLabels(button, false);

                    if (icon) {
                        icon.classList.remove('rotate-180');
                    }

                    answersContainer.classList.add('hidden');

                    return;
                }

                button.setAttribute('aria-expanded', 'true');
                updateToggleLabels(button, true);

                if (icon) {
                    icon.classList.add('rotate-180');
                }

                answersContainer.classList.remove('hidden');

                if (button.dataset.loaded === 'true') {
                    return;
                }

                const url = button.dataset.loadUrl;

                if (!url) {
                    answersContainer.innerHTML = '<p class="text-xs text-red-600">Посилання для завантаження не вказане.</p>';
                    button.dataset.loaded = 'error';

                    return;
                }

                button.dataset.loaded = 'loading';
                answersContainer.innerHTML = '<p class="text-xs text-gray-500">Завантаження…</p>';

                try {
                    const response = await fetch(url, {
                        headers: {
                            'Accept': 'application/json',
                        },
                    });

                    const payload = await response.json().catch(function () {
                        return null;
                    });

                    if (!response.ok) {
                        const message = payload && typeof payload.message === 'string'
                            ? payload.message
                            : 'Не вдалося завантажити варіанти.';
                        throw new Error(message);
                    }

                    answersContainer.innerHTML = payload && typeof payload.html === 'string'
                        ? payload.html
                        : '';
                    button.dataset.loaded = 'true';

                    if (!answersContainer.innerHTML.trim()) {
                        answersContainer.innerHTML = '<p class="text-xs text-gray-500">Варіанти відповіді не знайдені.</p>';
                    }
                } catch (error) {
                    const message = error && typeof error.message === 'string' && error.message
                        ? error.message
                        : 'Не вдалося завантажити варіанти.';

                    answersContainer.innerHTML = '<p class="text-xs text-red-600">' + message + '</p>';
                    button.dataset.loaded = 'error';
                    showFeedback(message, 'error');
                }
            };

            document.addEventListener('click', function (event) {
                const folderButton = event.target.closest('[data-folder-toggle]');

                if (folderButton) {
                    event.preventDefault();
                    handleFolderToggle(folderButton);

                    return;
                }

                const seederButton = event.target.closest('[data-seeder-toggle]');

                if (seederButton) {
                    event.preventDefault();
                    handleSeederToggle(seederButton);

                    return;
                }

                const questionButton = event.target.closest('[data-question-toggle]');

                if (questionButton) {
                    event.preventDefault();
                    handleQuestionToggle(questionButton);

                    return;
                }

                const sourceButton = event.target.closest('[data-source-toggle]');

                if (sourceButton) {
                    event.preventDefault();
                    handleSourceToggle(sourceButton);
                }
            });

            document.addEventListener('submit', async function (event) {
                const form = event.target.closest('form[data-question-delete-form]');

                if (!form) {
                    return;
                }

                event.preventDefault();

                const confirmMessage = form.dataset.confirm;

                if (confirmMessage && !window.confirm(confirmMessage)) {
                    return;
                }

                const questionId = form.dataset.questionId;
                const seedRunId = form.dataset.seedRunId;
                const categoryKey = form.dataset.categoryKey;
                const sourceKey = form.dataset.sourceKey;
                const submitButton = form.querySelector('button[type="submit"]');

                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.classList.add('opacity-60', 'cursor-not-allowed');
                }

                try {
                    const response = await fetch(form.action, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': csrfToken,
                            'Accept': 'application/json',
                        },
                    });

                    const payload = await response.json().catch(function () {
                        return null;
                    });

                    if (!response.ok) {
                        const errorMessage = payload && typeof payload.message === 'string'
                            ? payload.message
                            : 'Не вдалося видалити питання.';
                        throw new Error(errorMessage);
                    }

                    const questionContainer = document.querySelector('[data-question-container][data-question-id="' + questionId + '"]');

                    if (questionContainer) {
                        questionContainer.remove();
                    }

                    decrementNumericContent(document.querySelectorAll('[data-seed-run-question-count][data-seed-run-id="' + seedRunId + '"]'));
                    decrementNumericContent(document.querySelectorAll('[data-category-question-count][data-seed-run-id="' + seedRunId + '"][data-category-key="' + categoryKey + '"]'));
                    decrementNumericContent(document.querySelectorAll('[data-source-question-count][data-seed-run-id="' + seedRunId + '"][data-category-key="' + categoryKey + '"][data-source-key="' + sourceKey + '"]'));

                    cleanupEmptyGroups(seedRunId, categoryKey, sourceKey);

                    const successMessage = payload && typeof payload.message === 'string'
                        ? payload.message
                        : 'Питання успішно видалено.';

                    showFeedback(successMessage);
                } catch (error) {
                    const fallbackErrorMessage = error && typeof error.message === 'string' && error.message
                        ? error.message
                        : 'Не вдалося видалити питання.';

                    showFeedback(fallbackErrorMessage, 'error');

                    if (submitButton) {
                        submitButton.disabled = false;
                        submitButton.classList.remove('opacity-60', 'cursor-not-allowed');
                    }
                }
            });
        });
    </script>
@endsection
