<div class="mt-4 flex justify-end">
    <button
        type="button"
        id="restart-test"
        class="inline-flex items-center justify-center gap-2 rounded-xl border border-stone-300 px-4 py-2 text-sm font-medium text-stone-700 transition hover:bg-stone-100 focus:outline-none focus:ring-2 focus:ring-stone-500/50"
    >
        Почати тест знову
    </button>
</div>
