<?php return [
    'welcome' => 'Ласкаво просимо до EnglishApp!',
    'dictionary' => 'Словник',
    'train' => 'Тренування',
    'about' => 'Про сайт',
    'search_placeholder' => 'Пошук по сайту...',
];